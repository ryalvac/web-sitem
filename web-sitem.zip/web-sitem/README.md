# Web sitem — Reşat Yalvaç

Kişisel portfolyom: veri analizi, yapay zekâ ve finans projeleri.

**Site:** https://ryalvac.github.io/web-sitem/

Anadolu Üniversitesi Büyük Veri Analistliği öğrencisiyim. Python ve R ile çalışıyor; altın trade botları ve TradingView indikatörleri geliştiriyorum.

Sitede etkileşimli 3D Bitcoin ve altın sahnesi, proje sunumları ve temsili finans grafiği bulunur. Grafik verileri sentetiktir.

Bu depo GitHub Pages için hazırlanmış statik yayın dosyalarını içerir. React, TypeScript, Three.js, Motion, Lenis ve Vite ile geliştirilmiştir.
